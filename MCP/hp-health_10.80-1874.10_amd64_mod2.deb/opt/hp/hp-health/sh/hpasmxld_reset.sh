#!/bin/sh
#
# © Copyright 2015 Hewlett Packard Enterprise Development LP..
#
# #####################################################################
# ## This routine will restart the hpasm system management stack.    ##
# ## This is called when we get a serious error during the           ##
# ## initialization of the hpasmxld daemon                           ##
# #####################################################################

# Give the hpasmxld application time to unload. It can get hung up in the
# OpenIPMI driver if we have a bad reset.

sleep 10

# Stop the stack and wait one minute for iLO to finish resetting.
HP_SNMP_AGENTS=0
if ps -e | grep -q cma; then
        HP_SNMP_AGENTS=1
	if [-d /usr/lib/systemd/]; then
		sh /usr/lib/systemd/scripts/hp-snmp-agents.sh stop
	else
        sh /etc/init.d/hp-snmp-agents stop
	fi
fi
if [-d /usr/lib/systemd/]; then
	sh /usr/lib/systemd/scripts/hp-health.sh stop
	sleep 60
	sh /usr/lib/systemd/scripts/hp-health.sh start
else
	/etc/init.d/hp-health stop
	sleep 60
	/etc/init.d/hp-health start
fi

if [ $HP_SNMP_AGENTS -eq 1 ]; then
	if [-d /usr/lib/systemd/]; then
                sh /usr/lib/systemd/scripts/hp-snmp-agents.sh start
	else
        /etc/init.d/hp-snmp-agents start
	fi
fi
